﻿namespace DemoCalculatorLib
{
    partial class UserControl1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.additionButton = new System.Windows.Forms.Button();
            this.subtractionButton = new System.Windows.Forms.Button();
            this.decimalButton = new System.Windows.Forms.Button();
            this.Sevenbutton = new System.Windows.Forms.Button();
            this.changeSignButton = new System.Windows.Forms.Button();
            this.Twobutton = new System.Windows.Forms.Button();
            this.zerobutton = new System.Windows.Forms.Button();
            this.Onebutton = new System.Windows.Forms.Button();
            this.Fourbutton = new System.Windows.Forms.Button();
            this.Fivebutton = new System.Windows.Forms.Button();
            this.Sixbutton = new System.Windows.Forms.Button();
            this.multiplicationButton = new System.Windows.Forms.Button();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView1 = new System.Windows.Forms.ListView();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.divisionButton = new System.Windows.Forms.Button();
            this.Ninebutton = new System.Windows.Forms.Button();
            this.Threebutton = new System.Windows.Forms.Button();
            this.Eightbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tableLayoutPanel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.listView1);
            this.splitContainer1.Size = new System.Drawing.Size(500, 400);
            this.splitContainer1.SplitterDistance = 307;
            this.splitContainer1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.zerobutton, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.changeSignButton, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.decimalButton, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.additionButton, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.Onebutton, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Twobutton, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.Threebutton, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.subtractionButton, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.button15, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.Fourbutton, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Fivebutton, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.Sixbutton, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.multiplicationButton, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.Sevenbutton, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Eightbutton, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.Ninebutton, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.divisionButton, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.Clearbutton, 4, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(303, 396);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.textBox1, 5);
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(3, 25);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(297, 29);
            this.textBox1.TabIndex = 0;
            // 
            // button15
            // 
            this.button15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button15.Location = new System.Drawing.Point(245, 242);
            this.button15.Margin = new System.Windows.Forms.Padding(5);
            this.button15.Name = "button15";
            this.tableLayoutPanel1.SetRowSpan(this.button15, 2);
            this.button15.Size = new System.Drawing.Size(53, 149);
            this.button15.TabIndex = 10;
            this.button15.Text = "=";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // additionButton
            // 
            this.additionButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.additionButton.Location = new System.Drawing.Point(185, 321);
            this.additionButton.Margin = new System.Windows.Forms.Padding(5);
            this.additionButton.Name = "additionButton";
            this.additionButton.Size = new System.Drawing.Size(50, 70);
            this.additionButton.TabIndex = 14;
            this.additionButton.Text = "+";
            this.additionButton.UseVisualStyleBackColor = true;
            // 
            // subtractionButton
            // 
            this.subtractionButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.subtractionButton.Location = new System.Drawing.Point(185, 242);
            this.subtractionButton.Margin = new System.Windows.Forms.Padding(5);
            this.subtractionButton.Name = "subtractionButton";
            this.subtractionButton.Size = new System.Drawing.Size(50, 69);
            this.subtractionButton.TabIndex = 9;
            this.subtractionButton.Text = "-";
            this.subtractionButton.UseVisualStyleBackColor = true;
            // 
            // decimalButton
            // 
            this.decimalButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.decimalButton.Location = new System.Drawing.Point(125, 321);
            this.decimalButton.Margin = new System.Windows.Forms.Padding(5);
            this.decimalButton.Name = "decimalButton";
            this.decimalButton.Size = new System.Drawing.Size(50, 70);
            this.decimalButton.TabIndex = 18;
            this.decimalButton.Text = ".";
            this.decimalButton.UseVisualStyleBackColor = true;
            // 
            // Sevenbutton
            // 
            this.Sevenbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Sevenbutton.Location = new System.Drawing.Point(5, 84);
            this.Sevenbutton.Margin = new System.Windows.Forms.Padding(5);
            this.Sevenbutton.Name = "Sevenbutton";
            this.Sevenbutton.Size = new System.Drawing.Size(50, 69);
            this.Sevenbutton.TabIndex = 1;
            this.Sevenbutton.Text = "7";
            this.Sevenbutton.UseVisualStyleBackColor = true;
            // 
            // changeSignButton
            // 
            this.changeSignButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.changeSignButton.Location = new System.Drawing.Point(65, 321);
            this.changeSignButton.Margin = new System.Windows.Forms.Padding(5);
            this.changeSignButton.Name = "changeSignButton";
            this.changeSignButton.Size = new System.Drawing.Size(50, 70);
            this.changeSignButton.TabIndex = 17;
            this.changeSignButton.Text = "+/-";
            this.changeSignButton.UseVisualStyleBackColor = true;
            // 
            // Twobutton
            // 
            this.Twobutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Twobutton.Location = new System.Drawing.Point(65, 242);
            this.Twobutton.Margin = new System.Windows.Forms.Padding(5);
            this.Twobutton.Name = "Twobutton";
            this.Twobutton.Size = new System.Drawing.Size(50, 69);
            this.Twobutton.TabIndex = 12;
            this.Twobutton.Text = "2";
            this.Twobutton.UseVisualStyleBackColor = true;
            // 
            // zerobutton
            // 
            this.zerobutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zerobutton.Location = new System.Drawing.Point(5, 321);
            this.zerobutton.Margin = new System.Windows.Forms.Padding(5);
            this.zerobutton.Name = "zerobutton";
            this.zerobutton.Size = new System.Drawing.Size(50, 70);
            this.zerobutton.TabIndex = 16;
            this.zerobutton.Text = "0";
            this.zerobutton.UseVisualStyleBackColor = true;
            // 
            // Onebutton
            // 
            this.Onebutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Onebutton.Location = new System.Drawing.Point(5, 242);
            this.Onebutton.Margin = new System.Windows.Forms.Padding(5);
            this.Onebutton.Name = "Onebutton";
            this.Onebutton.Size = new System.Drawing.Size(50, 69);
            this.Onebutton.TabIndex = 11;
            this.Onebutton.Text = "1";
            this.Onebutton.UseVisualStyleBackColor = true;
            // 
            // Fourbutton
            // 
            this.Fourbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Fourbutton.Location = new System.Drawing.Point(5, 163);
            this.Fourbutton.Margin = new System.Windows.Forms.Padding(5);
            this.Fourbutton.Name = "Fourbutton";
            this.Fourbutton.Size = new System.Drawing.Size(50, 69);
            this.Fourbutton.TabIndex = 6;
            this.Fourbutton.Text = "4";
            this.Fourbutton.UseVisualStyleBackColor = true;
            // 
            // Fivebutton
            // 
            this.Fivebutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Fivebutton.Location = new System.Drawing.Point(65, 163);
            this.Fivebutton.Margin = new System.Windows.Forms.Padding(5);
            this.Fivebutton.Name = "Fivebutton";
            this.Fivebutton.Size = new System.Drawing.Size(50, 69);
            this.Fivebutton.TabIndex = 7;
            this.Fivebutton.Text = "5";
            this.Fivebutton.UseVisualStyleBackColor = true;
            // 
            // Sixbutton
            // 
            this.Sixbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Sixbutton.Location = new System.Drawing.Point(125, 163);
            this.Sixbutton.Margin = new System.Windows.Forms.Padding(5);
            this.Sixbutton.Name = "Sixbutton";
            this.Sixbutton.Size = new System.Drawing.Size(50, 69);
            this.Sixbutton.TabIndex = 8;
            this.Sixbutton.Text = "6";
            this.Sixbutton.UseVisualStyleBackColor = true;
            // 
            // multiplicationButton
            // 
            this.multiplicationButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.multiplicationButton.Location = new System.Drawing.Point(185, 163);
            this.multiplicationButton.Margin = new System.Windows.Forms.Padding(5);
            this.multiplicationButton.Name = "multiplicationButton";
            this.multiplicationButton.Size = new System.Drawing.Size(50, 69);
            this.multiplicationButton.TabIndex = 4;
            this.multiplicationButton.Text = "*";
            this.multiplicationButton.UseVisualStyleBackColor = true;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Журнал";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(0, 0);
            this.listView1.Margin = new System.Windows.Forms.Padding(5);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(185, 396);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // Clearbutton
            // 
            this.Clearbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Clearbutton.Location = new System.Drawing.Point(245, 84);
            this.Clearbutton.Margin = new System.Windows.Forms.Padding(5);
            this.Clearbutton.Name = "Clearbutton";
            this.tableLayoutPanel1.SetRowSpan(this.Clearbutton, 2);
            this.Clearbutton.Size = new System.Drawing.Size(53, 148);
            this.Clearbutton.TabIndex = 0;
            this.Clearbutton.Text = "Очистить";
            this.Clearbutton.UseVisualStyleBackColor = true;
            // 
            // divisionButton
            // 
            this.divisionButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.divisionButton.Location = new System.Drawing.Point(185, 84);
            this.divisionButton.Margin = new System.Windows.Forms.Padding(5);
            this.divisionButton.Name = "divisionButton";
            this.divisionButton.Size = new System.Drawing.Size(50, 69);
            this.divisionButton.TabIndex = 0;
            this.divisionButton.Text = "/";
            this.divisionButton.UseVisualStyleBackColor = true;
            // 
            // Ninebutton
            // 
            this.Ninebutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ninebutton.Location = new System.Drawing.Point(125, 84);
            this.Ninebutton.Margin = new System.Windows.Forms.Padding(5);
            this.Ninebutton.Name = "Ninebutton";
            this.Ninebutton.Size = new System.Drawing.Size(50, 69);
            this.Ninebutton.TabIndex = 3;
            this.Ninebutton.Text = "9";
            this.Ninebutton.UseVisualStyleBackColor = true;
            // 
            // Threebutton
            // 
            this.Threebutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Threebutton.Location = new System.Drawing.Point(125, 242);
            this.Threebutton.Margin = new System.Windows.Forms.Padding(5);
            this.Threebutton.Name = "Threebutton";
            this.Threebutton.Size = new System.Drawing.Size(50, 69);
            this.Threebutton.TabIndex = 13;
            this.Threebutton.Text = "3";
            this.Threebutton.UseVisualStyleBackColor = true;
            // 
            // Eightbutton
            // 
            this.Eightbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Eightbutton.Location = new System.Drawing.Point(65, 84);
            this.Eightbutton.Margin = new System.Windows.Forms.Padding(5);
            this.Eightbutton.Name = "Eightbutton";
            this.Eightbutton.Size = new System.Drawing.Size(50, 69);
            this.Eightbutton.TabIndex = 2;
            this.Eightbutton.Text = "8";
            this.Eightbutton.UseVisualStyleBackColor = true;
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(500, 400);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button zerobutton;
        private System.Windows.Forms.Button changeSignButton;
        private System.Windows.Forms.Button decimalButton;
        private System.Windows.Forms.Button additionButton;
        private System.Windows.Forms.Button Onebutton;
        private System.Windows.Forms.Button Twobutton;
        private System.Windows.Forms.Button Threebutton;
        private System.Windows.Forms.Button subtractionButton;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button Fourbutton;
        private System.Windows.Forms.Button Fivebutton;
        private System.Windows.Forms.Button Sixbutton;
        private System.Windows.Forms.Button multiplicationButton;
        private System.Windows.Forms.Button Sevenbutton;
        private System.Windows.Forms.Button Eightbutton;
        private System.Windows.Forms.Button Ninebutton;
        private System.Windows.Forms.Button divisionButton;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
    }
}
